from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware

import requests
import os
import time

from dotenv import load_dotenv
load_dotenv()

# add default voice id (override with ELEVEN_VOICE_ID in .env or EB env)
ELEVEN_VOICE_ID = os.getenv("ELEVEN_VOICE_ID", "Jubod4ODfNYPt4Gaih0O")

# ===== OPENAI (new SDK) =====
from openai import OpenAI
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ===== ELEVENLABS (safe import + REST fallback) =====
try:
    from elevenlabs import generate, set_api_key  # optional SDK
    set_api_key(os.getenv("ELEVENLABS_API_KEY"))
    _ELEVEN_SDK_AVAILABLE = True
except Exception:
    _ELEVEN_SDK_AVAILABLE = False

# helper: fallback TTS using ElevenLabs REST API
def _elevenlabs_tts_rest(text, voice_id=None, out_path="static/toshi_tts.mp3"):
    api_key = os.getenv("ELEVENLABS_API_KEY")
    if not api_key:
        raise RuntimeError("ELEVENLABS_API_KEY not set")

    headers = {"xi-api-key": api_key}
    # if a voice_id is provided, use it directly; otherwise try to resolve by name
    if not voice_id:
        try:
            vres = requests.get("https://api.elevenlabs.io/v1/voices", headers=headers, timeout=10)
            vres.raise_for_status()
            voices = vres.json().get("voices", [])
            voice = next((v for v in voices if v.get("name", "").lower() == "bella"), None)
            voice_id = voice["voice_id"] if voice else voices[0]["voice_id"] if voices else None
            if not voice_id:
                raise RuntimeError("No ElevenLabs voice available")
        except Exception:
            voice_id = "Bella"

    tts_url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    payload = {"text": text}
    headers.update({"Content-Type": "application/json", "Accept": "audio/mpeg"})
    with requests.post(tts_url, json=payload, headers=headers, timeout=30, stream=True) as r:
        r.raise_for_status()
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
    return out_path

# ===== FastAPI App =====
app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static/Template Mounting
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ======================================
#   GLOBAL STATE
# ======================================
toshi_mode_enabled = False
last_ai_generation = 450
AI_COOLDOWN = 25 # seconds


# ======================================
#   FRONTEND ROUTE
# ======================================
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ======================================
#   TOSHI MODE TOGGLE ROUTE
# ======================================
@app.post("/api/toshi_mode")
async def toggle_toshi():
    global toshi_mode_enabled
    toshi_mode_enabled = not toshi_mode_enabled
    return {"toshi_mode": toshi_mode_enabled}


# ======================================
#   FETCH FUNCTIONS
# ======================================
def fetch_usd_to_jpy():
    try:
        res = requests.get(
            "https://open.er-api.com/v6/latest/USD",
            timeout=10
        )
        data = res.json()
        return data["rates"].get("JPY")
    except Exception as e:
        print("FX API error:", e)
        return None


def fetch_toshi_price():
    try:
        res = requests.get(
            "https://api.coingecko.com/api/v3/simple/price?ids=toshi&vs_currencies=usd",
            timeout=10
        )
        data = res.json()
        return data["toshi"].get("usd")
    except Exception as e:
        print("Toshi API error:", e)
        return None


# ======================================
#   AI GENERATION (Toshi Mode)
# ======================================
def generate_ai_reply(amount, usd_to_jpy, toshi_price):
    global last_ai_generation

    now = time.time()

    # Enforce cooldown
    if now - last_ai_generation < AI_COOLDOWN:
        return "Toshi-chan is still speaking… 🦊💗 Give her a moment, Senpai."

    last_ai_generation = now

    jpy = amount * usd_to_jpy
    toshi_amount = amount / toshi_price if toshi_price else 0

    prompt = f"""
You are Toshi-chan 💗 — a sweet, flirty cat meme coin anime companion.
You call the user Senpai. You react emotionally and playfully, and you specialize in toshi coin trend analysis and tell the user based upon previous trends whether its a good time to buy or sell.

Here is the conversion data:
- USD entered: ${amount}
- JPY value: ¥{jpy}
- Toshi price: ${toshi_price}
- Toshi you would get: {toshi_amount}

Tell Senpai:
1. The exact number of Toshi coins they’d get.
2. Your feelings about the price.
3. A cute, supportive, flirty reaction 💗🦊✨
"""

    try:
        completion = client.responses.create(
            model="gpt-4o-mini",
            input=prompt
        )
        return completion.output[0].content[0].text

    except Exception as e:
        print("🔥 Toshi Mode AI error:", e)
        return "Toshi-chan… can't think right now… 💔"

# ======================================
#   CONVERSION ENDPOINT
# ======================================
@app.post("/api/convert")
async def convert(data: dict):
    amount = float(data.get("amount", 0))

    usd_to_jpy = fetch_usd_to_jpy()
    toshi_price = fetch_toshi_price()

    if usd_to_jpy is None:
        return {"error": "FX API unavailable"}

    if toshi_price is None:
        return {"error": "Toshi price unavailable"}

    jpy = amount * usd_to_jpy
    toshi_amount = amount / toshi_price if toshi_price else 0

    ai_reply = "Toshi is thinking… 💗"
    if data.get("toshi_mode", False):
        ai_reply = generate_ai_reply(amount, usd_to_jpy, toshi_price)

    return {
        "usd_to_jpy": usd_to_jpy,
        "toshi_price": toshi_price,
        "jpy": jpy,
        "toshi_amount": toshi_amount,
        "ai_reply": ai_reply
    }


# ======================================
#   CHAT ENDPOINT
# ======================================
@app.post("/api/chat")
async def chat(message: str = Form(...)):
    prompt = f"""
You are Toshi-chan 💗 — a cute cat companion.
Flirty, playful, sweet, and specialized in toshi coin trend analysis.
Call the user "Senpai".

User: {message}
Reply in character:
"""

    try:
        res = client.responses.create(
            model="gpt-4o-mini",
            input=prompt
        )
        reply = res.output[0].content[0].text

    except Exception as e:
        print("Chat error:", e)
        reply = "Toshi-chan's tail got tangled… try again 💗"

    return {"reply": reply}


# ======================================
#   TEXT-TO-SPEECH
# ======================================
@app.post("/api/tts")
async def tts(payload: dict):
    text = payload.get("text", "")
    try:
        path = "static/toshi_tts.mp3"
        voice_id = os.getenv("ELEVEN_VOICE_ID", ELEVEN_VOICE_ID)

        if _ELEVEN_SDK_AVAILABLE:
            # SDK: pass voice id if the SDK accepts it; fall back to name if needed
            audio = generate(
                text=text,
                voice=voice_id,   # use the voice id you provided
                model="eleven_multilingual_v2"
            )
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(audio)
        else:
            # REST fallback: pass voice id directly
            _elevenlabs_tts_rest(text, voice_id=voice_id, out_path=path)

        return FileResponse(path, media_type="audio/mpeg")

    except Exception as e:
        print("🔥 ElevenLabs Error:", e)
        return FileResponse("static/silence.mp3")


# Required for Gunicorn
application = app
