// ==============================
// DOM REFERENCES
// ==============================

const img = document.getElementById("toshi-img");
const video = document.getElementById("toshi-video");
const chat = document.getElementById("chat");
const audio = document.getElementById("toshi-voice");
const toshiBtn = document.getElementById("toshi-btn");

let toshiMode = false;
let isWaitingForAudio = false;


// ==============================
// Add message to chat
// ==============================
function addMessage(msg) {
    chat.innerHTML = "<p>" + msg + "</p>";
}


// ==============================
// Toggle Toshi Mode
// ==============================
function toggleToshiMode() {
    fetch("/api/toshi_mode", { method: "POST" })
        .then(r => r.json())
        .then(data => {
            toshiMode = data.toshi_mode;

            if (toshiMode) {
                // 🔥 Switch TO animation
                img.style.display = "none";
                video.style.display = "block";

                try {
                    video.currentTime = 0;
                    video.muted = true;      // required for autoplay
                    video.play().catch(err => {
                        console.log("Autoplay blocked, retrying:", err);
                        video.muted = true;
                        video.play();
                    });
                } catch (err) {
                    console.log("Video play error:", err);
                }

                toshiBtn.innerText = "Toshi Mode On";

            } else {
                // ❄ Switch TO static image
                video.pause();
                video.style.display = "none";
                img.style.display = "block";

                toshiBtn.innerText = "Toshi Mode Off";
            }
        })
        .catch(err => console.error("Toggle error:", err));
}



// ==============================
// Main Convert Function
// ==============================
async function convert() {
    const amount = parseFloat(document.getElementById("usd-input").value);

    if (!amount) {
        addMessage("Please enter an amount first 💗");
        return;
    }

    // Prevent spam while audio is playing
    if (isWaitingForAudio) return;

    const payload = {
        amount: amount,
        toshi_mode: toshiMode
    };

    try {
        const res = await fetch("/api/convert", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        addMessage(`
            USD → JPY: ¥${data.jpy.toFixed(2)}<br>
            Toshi price: $${data.toshi_price}<br>
            Coins you'd get: ${data.toshi_amount.toFixed(4)} 🪙<br><br>
            💗 Toshi-chan: ${data.ai_reply}
        `);

        if (toshiMode) {
            isWaitingForAudio = true;

            const ttsRes = await fetch("/api/tts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: data.ai_reply })
            });

            const blob = await ttsRes.blob();
            audio.src = URL.createObjectURL(blob);
            audio.play();
        }

    } catch (err) {
        console.error("Convert error:", err);
        addMessage("Something went wrong 💔");
    }
}


// ==============================
// Auto-refresh ONLY when TTS ends
// ==============================
audio.addEventListener("ended", () => {
    isWaitingForAudio = false;

    if (toshiMode) {
        console.log("🎤 Toshi finished speaking — refreshing…");
        convert();
    }
});
